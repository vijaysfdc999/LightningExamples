# Examples of Salesforce Lightning Components

### Dynamically Instantiate and destroy Lightning Components – Modal dialog component 

[Blog post explaining component](http://www.jitendrazaa.com/blog/salesforce/dynamically-instantiate-and-destroy-lightning-components-modal-dialog-component/)

![Demo](https://github.com/JitendraZaa/LightningExamples/blob/master/Demo%20images/Ligtning%20Modal%20Window.gif "Modal dialog Demo")

### Disable Pull-to-Refresh in Salesforce1 for Lightning Components

[Blog post explaining component](http://www.jitendrazaa.com/blog/salesforce/disable-pull-to-refresh-in-salesforce1-for-lightning-components/)

![Demo](https://github.com/JitendraZaa/LightningExamples/blob/master/Demo%20images/Disable%20Pull-to-Refresh%20in%20Salesforce1%20for%20Lightning%20Components.gif "Disable Pull-to-Refresh in Salesforce1 for Lightning Components")

