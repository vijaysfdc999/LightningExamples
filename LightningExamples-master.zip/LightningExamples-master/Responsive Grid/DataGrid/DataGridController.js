({
	doInit : function(component, event, helper) {
		helper.OnInit(component, event, helper);
        console.log('Executed');
	}
})